package com.cococollection.kidswear;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
public class MainActivity extends Activity {
 private WebView webView;
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState); webView=new WebView(this); setContentView(webView);
  WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
  webView.setWebViewClient(new WebViewClient(){
   private boolean handle(String url){
    if(url.startsWith("https://")||url.startsWith("http://")||url.startsWith("upi://")||url.startsWith("whatsapp://")){
     try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception ignored){} return true;
    } return false;
   }
   @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){return handle(r.getUrl().toString());}
   @Override public boolean shouldOverrideUrlLoading(WebView v,String u){return handle(u);}
  });
  webView.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
