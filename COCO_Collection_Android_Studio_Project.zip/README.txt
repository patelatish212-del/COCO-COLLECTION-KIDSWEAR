COCO COLLECTION KIDS WEAR — ANDROID APP PROJECT

This is an Android Studio project, not a precompiled APK. It includes a GitHub Actions workflow to build the APK.

HOW TO GET AN APK
1. Create a GitHub repository.
2. Upload all files and folders in this ZIP into the repository, preserving the folder structure.
3. Open the repository's Actions tab and select "Build COCO Android APK".
4. Tap "Run workflow" and wait until the run completes successfully.
5. Open the completed run and download the artifact "COCO-Collection-Kids-Wear-APK".
6. Extract the downloaded artifact ZIP. It contains app-debug.apk. Open it on your Android phone to install.
7. If Android asks, allow installing apps from the app/source you used.

LOCAL BUILD
Open the folder in Android Studio with Android SDK Platform 35 installed. Build > Build APK(s).
The APK will be at app/build/outputs/apk/debug/app-debug.apk.

FEATURES
- Itemized bills, quantity/rate, discount, received amount and balance
- Shop details and contacts from the reference image
- UPI QR option, WhatsApp bill summary, print/save PDF
- Bills stored locally; JSON export backup

IMPORTANT
Verify the address, phone numbers and UPI ID before use. UPI QR graphic uses an online QR image service and needs internet. Enter your actual UPI ID in Shop & Payment. This is a debug APK for testing, not a Play Store release.
